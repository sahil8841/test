using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace assignment_sahil.Pages.Products
{
    public class CreateModel : PageModel
    {
        public ProductInfo productInfo=new ProductInfo();
        public String errorMsg = "";
        public String sMsg = "";
        public void OnGet()
        {
        }

        public void OnPost() 
        {
            productInfo.product = Request.Form["product"];
            productInfo.about = Request.Form["about"];

            if (productInfo.product.Length == 0 || productInfo.about.Length == 0)
            {
                errorMsg = "All the fields are required";
                return;
            }

            try
            {
                String con = "Data Source=.\\sqlexpress;Initial Catalog=list;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(con))
                { 
                connection.Open();
                    String sql = "INSERT INTO products"+
                        "(product,about) VALUES"+
                        "(@product,@about)";

                    using (SqlCommand command = new SqlCommand(sql, connection)) {
                        command.Parameters.AddWithValue("@product", productInfo.product);
                        command.Parameters.AddWithValue("@about", productInfo.about);
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex) { 
            errorMsg = ex.Message;
                return;
            }

            productInfo.product = "";
            productInfo.about = "";
            sMsg = "New Product added";

            Response.Redirect("/Products/Index");

        }
    }
}
