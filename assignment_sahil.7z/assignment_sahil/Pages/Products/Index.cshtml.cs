using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace assignment_sahil.Pages.Products
{
    public class IndexModel : PageModel
    {
        public List<ProductInfo> listProducts = new List<ProductInfo>();
        public void OnGet()
        {
            try
            {
                String con = "Data Source=.\\sqlexpress;Initial Catalog=list;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(con))
                {
                    connection.Open();
                    String sql = "select * FROM products";
                    using (SqlCommand com = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = com.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                ProductInfo productinfo = new ProductInfo();
                                productinfo.id = ""+reader.GetInt32(0);
                                productinfo.product =  reader.GetString(1);
                                productinfo.about = reader.GetString(2);
                                productinfo.created_at =  reader.GetDateTime(3).ToString();

                                listProducts.Add(productinfo);

                            }
                        }
                    }
                }
            }
            catch (Exception ex) 
            {
            }
        }

    }
    public class ProductInfo 
    {
        public String id;
        public String product;
        public String about;
        public String created_at;   
    }
}
