using Microsoft.AspNetCore.Mvc;
using System;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace assignment_sahil.Pages.Products
{
    public class EditModel : PageModel
    {
        public ProductInfo productInfo = new ProductInfo();
        public String errorMsg = "";
        public String sMsg = "";

        public object ConvertTo { get; private set; }

        public void OnGet()
        {
            String id = Request.Query["id"];

            try
            {
                String con = "Data Source=.\\sqlexpress;Initial Catalog=list;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(con))
                {
                    connection.Open();
                    String sql = "SELECT * FROM products WHERE id=@id";
                    using (SqlCommand com = new SqlCommand(sql, connection))
                    {
                        com.Parameters.AddWithValue("@id", id);
                        using (SqlDataReader reader = com.ExecuteReader())
                        {
                            if (reader.Read())
                            {

                                productInfo.id = ""+reader.GetInt32(0);
                                productInfo.product = reader.GetString(1);
                                productInfo.about = reader.GetString(2);




                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                errorMsg = ex.Message;
                return;
            }
        }
    

        public void OnPost()
        {
        productInfo.id = Request.Form["id"];
        productInfo.product = Request.Form["product"];
        productInfo.about = Request.Form["about"];

        if (productInfo.product.Length == 0 || productInfo.about.Length == 0)
        {
            errorMsg = "All the fields are required";
            return;
        }
        try
        {
            String con = "Data Source=.\\sqlexpress;Initial Catalog=list;Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(con))
            {
                connection.Open();
                String sql = "UPDATE products " +
                             "SET product = @product, about = @about " +
                             "WHERE id = @id";

                using (SqlCommand command = new SqlCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@id", productInfo.id);
                    command.Parameters.AddWithValue("@product", productInfo.product);
                    command.Parameters.AddWithValue("@about", productInfo.about);

                    command.ExecuteNonQuery();
                }
            }
        }
        catch (Exception ex)
        {
            errorMsg = ex.Message;
            return;
        }


        Response.Redirect("/Products/Index");
        }
    }
}

